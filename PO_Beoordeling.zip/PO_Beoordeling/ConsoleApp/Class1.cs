using System;
using FUNC;
using System.Web;
using System.IO; 
using BO;

namespace ConsoleApp
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	class Class1
	{
		[STAThread]
		public static void Main()
		{
			using(BO.DAL_OleDb oDal = new DAL_OleDb())
			{
				cTLs colTLs = new cTLs(oDal).GetAsList();
				cTL oTL = (cTL)colTLs[0];
				Console.WriteLine(oTL.TLNaam); 
			}
		}
	}
}
