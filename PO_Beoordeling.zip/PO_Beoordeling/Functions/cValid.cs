using System;

namespace FUNC
{
	/// <summary>
	/// Summary description for cValid.
	/// </summary>
	public class cValid
	{
		public cValid()
		{
			
		}
	}
}
